"""Unit tests for the stack expression evaluator reference project."""

import tempfile
import unittest
from pathlib import Path

from main import Stack, evaluate_expression, format_result, process_file, tokenize


class StackTests(unittest.TestCase):
    def test_new_stack_is_empty(self):
        self.assertTrue(Stack().is_empty())

    def test_push_then_peek(self):
        stack = Stack()
        stack.push(12)
        self.assertEqual(stack.peek(), 12)
        self.assertEqual(len(stack), 1)

    def test_pop_returns_last_item(self):
        stack = Stack()
        stack.push("first")
        stack.push("last")
        self.assertEqual(stack.pop(), "last")
        self.assertEqual(stack.pop(), "first")
        self.assertTrue(stack.is_empty())

    def test_pop_empty_raises(self):
        with self.assertRaises(IndexError):
            Stack().pop()

    def test_peek_empty_raises(self):
        with self.assertRaises(IndexError):
            Stack().peek()

    def test_peek_does_not_remove(self):
        stack = Stack()
        stack.push(8)
        stack.peek()
        self.assertEqual(len(stack), 1)


class TokenizerTests(unittest.TestCase):
    def test_tokenizes_spaces_and_operators(self):
        self.assertEqual(tokenize(" 12 + (3.5 * 2) "), ["12", "+", "(", "3.5", "*", "2", ")"])

    def test_empty_expression_rejected(self):
        with self.assertRaisesRegex(ValueError, "empty"):
            tokenize("   ")

    def test_invalid_character_rejected(self):
        with self.assertRaisesRegex(ValueError, "Invalid character"):
            tokenize("2 + x")


class EvaluationTests(unittest.TestCase):
    def test_multiplication_before_addition(self):
        self.assertEqual(evaluate_expression("3 + 5 * 2"), 13)

    def test_parentheses_and_precedence(self):
        self.assertEqual(evaluate_expression("(8 / 4) + 7 * 2"), 16)

    def test_negative_result(self):
        self.assertEqual(evaluate_expression("10 - (2 + 3) * 4"), -10)

    def test_left_associativity(self):
        self.assertEqual(evaluate_expression("20 / 5 * 2"), 8)

    def test_multiple_precedence_levels(self):
        self.assertEqual(evaluate_expression("2 + 3 * 4 - 5 / 5"), 13)

    def test_decimal_result(self):
        self.assertEqual(evaluate_expression("7 / 2"), 3.5)

    def test_decimal_operands(self):
        self.assertAlmostEqual(evaluate_expression("1.5 * 2 + 0.25"), 3.25)

    def test_integral_float_format(self):
        self.assertEqual(format_result(evaluate_expression("20 / 5")), "4")

    def test_mismatched_open_parenthesis(self):
        with self.assertRaisesRegex(ValueError, "Mismatched parentheses"):
            evaluate_expression("(2 + 3")

    def test_mismatched_close_parenthesis(self):
        with self.assertRaisesRegex(ValueError, "Mismatched parentheses"):
            evaluate_expression("2 + 3)")

    def test_division_by_zero(self):
        with self.assertRaisesRegex(ValueError, "Division by zero"):
            evaluate_expression("5 / 0")

    def test_rejects_missing_operator(self):
        with self.assertRaisesRegex(ValueError, "missing operator"):
            evaluate_expression("2 (3 + 4)")

    def test_rejects_unary_minus_operand(self):
        with self.assertRaisesRegex(ValueError, "left operand"):
            evaluate_expression("-5 + 2")

    def test_rejects_trailing_operator(self):
        with self.assertRaisesRegex(ValueError, "ends before an operand"):
            evaluate_expression("2 +")

    def test_rejects_empty_parentheses(self):
        with self.assertRaises(ValueError):
            evaluate_expression("()")


class FileProcessingTests(unittest.TestCase):
    def test_sample_file_results(self):
        sample = "3 + 5 * 2\n------\n(8 / 4) + 7 * 2\n------\n10 - (2 + 3) * 4\n"
        expected = "13\n------\n16\n------\n-10\n"
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            inp, out = root / "input.txt", root / "output.txt"
            inp.write_text(sample, encoding="utf-8")
            process_file(inp, out)
            self.assertEqual(out.read_text(encoding="utf-8"), expected)

    def test_blank_line_and_separator_preserved(self):
        sample = "3 + 4\n\n---\n2 * 5\n"
        expected = "7\n\n---\n10\n"
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            inp, out = root / "input.txt", root / "output.txt"
            inp.write_text(sample, encoding="utf-8")
            process_file(inp, out)
            self.assertEqual(out.read_text(encoding="utf-8"), expected)

    def test_invalid_line_does_not_stop_later_lines(self):
        sample = "3 + 4\n5 / 0\n2 * 6\n"
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            inp, out = root / "input.txt", root / "output.txt"
            inp.write_text(sample, encoding="utf-8")
            lines = process_file(inp, out)
            self.assertEqual(lines[0], "7")
            self.assertIn("Division by zero", lines[1])
            self.assertEqual(lines[2], "12")


if __name__ == "__main__":
    unittest.main(verbosity=2)
