from __future__ import annotations

import re
from pathlib import Path
from typing import Union

Number = Union[int, float]


class Stack:
    """A small LIFO stack with explicit push, pop, peek, and is_empty methods."""

    def __init__(self) -> None:
        self._items: list[object] = []

    def push(self, item: object) -> None:
        self._items.append(item)

    def pop(self) -> object:
        if self.is_empty():
            raise IndexError("Cannot pop from an empty stack.")
        return self._items.pop()

    def peek(self) -> object:
        if self.is_empty():
            raise IndexError("Cannot peek at an empty stack.")
        return self._items[-1]

    def is_empty(self) -> bool:
        return not self._items

    def __len__(self) -> int:
        return len(self._items)


PRECEDENCE = {"+": 1, "-": 1, "*": 2, "/": 2}
_TOKEN_RE = re.compile(r"(?:\d+(?:\.\d+)?|[()+\-*/])")


def tokenize(expression: str) -> list[str]:
    """Convert an expression to numeric/operator tokens; reject unknown text."""
    tokens: list[str] = []
    pos = 0
    while pos < len(expression):
        if expression[pos].isspace():
            pos += 1
            continue
        match = _TOKEN_RE.match(expression, pos)
        if match is None:
            raise ValueError(
                f"Invalid character or token at column {pos + 1}: {expression[pos:pos + 12]!r}"
            )
        tokens.append(match.group(0))
        pos = match.end()
    if not tokens:
        raise ValueError("Expression is empty.")
    return tokens


def _apply_top_operator(values: Stack, operators: Stack) -> None:
    """Apply the top binary operator to the top two values."""
    if operators.is_empty():
        raise ValueError("Invalid expression: missing operator.")
    operator = operators.pop()
    if operator not in PRECEDENCE:
        raise ValueError("Mismatched parentheses.")
    if len(values) < 2:
        raise ValueError("Invalid expression: operator is missing an operand.")

    right = values.pop()
    left = values.pop()
    assert isinstance(left, (int, float)) and isinstance(right, (int, float))

    if operator == "+":
        result: Number = left + right
    elif operator == "-":
        result = left - right
    elif operator == "*":
        result = left * right
    else:
        if right == 0:
            raise ValueError("Division by zero is not allowed.")
        result = left / right
    values.push(result)


def evaluate_expression(expression: str) -> Number:
    """Evaluate +, -, *, / and parentheses using separate stacks.

    Operands are non-negative integers or decimals. Unary operators (for
    example, an input operand written as -5) are not supported, but an
    arithmetic result may be negative.
    """
    tokens = tokenize(expression)
    values = Stack()
    operators = Stack()
    expect_operand = True

    for token in tokens:
        if token[0].isdigit():
            if not expect_operand:
                raise ValueError("Invalid expression: missing operator between operands.")
            number: Number = float(token) if "." in token else int(token)
            values.push(number)
            expect_operand = False

        elif token == "(":
            if not expect_operand:
                raise ValueError("Invalid expression: missing operator before '('.")
            operators.push(token)
            expect_operand = True

        elif token == ")":
            if expect_operand:
                raise ValueError("Invalid expression: empty parentheses or missing operand.")
            while not operators.is_empty() and operators.peek() != "(":
                _apply_top_operator(values, operators)
            if operators.is_empty():
                raise ValueError("Mismatched parentheses: no matching '('.")
            operators.pop()  # discard matching opening parenthesis
            expect_operand = False

        else:  # one of +, -, *, /
            if expect_operand:
                raise ValueError("Invalid expression: operator is missing a left operand.")
            while (
                not operators.is_empty()
                and operators.peek() != "("
                and PRECEDENCE[str(operators.peek())] >= PRECEDENCE[token]
            ):
                _apply_top_operator(values, operators)
            operators.push(token)
            expect_operand = True

    if expect_operand:
        raise ValueError("Invalid expression: expression ends before an operand.")

    while not operators.is_empty():
        if operators.peek() == "(":
            raise ValueError("Mismatched parentheses: no matching ')'.")
        _apply_top_operator(values, operators)

    if len(values) != 1:
        raise ValueError("Invalid expression: expected exactly one final result.")
    result = values.pop()
    assert isinstance(result, (int, float))
    return result


def format_result(result: Number) -> str:
    """Avoid a trailing .0 for mathematically integral float results."""
    if isinstance(result, float) and result.is_integer():
        return str(int(result))
    return str(result)


def _is_separator(line: str) -> bool:
    stripped = line.strip()
    return bool(stripped) and set(stripped) == {"-"}


def process_file(
    input_file: str | Path = "input.txt",
    output_file: str | Path = "output.txt",
) -> list[str]:
    """Evaluate each nonblank, nonseparator line and write the output file."""
    input_path = Path(input_file)
    output_path = Path(output_file)
    with input_path.open("r", encoding="utf-8") as source:
        input_lines = source.read().splitlines()

    output_lines: list[str] = []
    for line_number, line in enumerate(input_lines, start=1):
        stripped = line.strip()
        if stripped == "":
            output_lines.append("")
        elif _is_separator(line):
            output_lines.append(line)
        else:
            try:
                output_lines.append(format_result(evaluate_expression(stripped)))
            except (ValueError, IndexError) as exc:
                output_lines.append(f"Error on line {line_number}: {exc}")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    text = "\n".join(output_lines)
    if output_lines:
        text += "\n"
    with output_path.open("w", encoding="utf-8", newline="\n") as target:
        target.write(text)
    return output_lines


def main() -> int:
    try:
        process_file("input.txt", "output.txt")
    except OSError as exc:
        print(f"File processing failed: {exc}")
        return 1
    print("Evaluation complete. Results written to output.txt")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
